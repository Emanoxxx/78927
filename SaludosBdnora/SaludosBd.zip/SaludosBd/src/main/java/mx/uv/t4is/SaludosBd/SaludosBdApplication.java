package mx.uv.t4is.SaludosBd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaludosBdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaludosBdApplication.class, args);
	}

}
