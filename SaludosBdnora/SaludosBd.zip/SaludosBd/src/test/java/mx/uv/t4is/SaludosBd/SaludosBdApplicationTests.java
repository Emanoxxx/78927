package mx.uv.t4is.SaludosBd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludosBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
