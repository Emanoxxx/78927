#!/bin/sh

/etc/init.d/mysql start
java -jar jar/SaludosBd-0.0.1-SNAPSHOT.jar