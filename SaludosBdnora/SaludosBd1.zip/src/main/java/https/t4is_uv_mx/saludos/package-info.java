//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.29 a las 12:49:45 PM CST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "https://t4is.uv.mx/saludos", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package https.t4is_uv_mx.saludos;
