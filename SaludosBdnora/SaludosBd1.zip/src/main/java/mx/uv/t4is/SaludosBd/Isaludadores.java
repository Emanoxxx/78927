package mx.uv.t4is.SaludosBd;

import org.springframework.data.repository.CrudRepository;

public interface Isaludadores extends CrudRepository<Saludadores, Integer> {
    
}
